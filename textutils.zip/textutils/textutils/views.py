#i have created this file-abdullah
from django.http import HttpResponse
from django.shortcuts import render
def index(request):
   return render(request,"index.html")

def analyze(request):
    djtext=request.POST.get("text","default")
    removepunc=request.POST.get("removepunc","off")
    fullcaps=request.POST.get('fullcaps','off')
    newlineremover=request.POST.get("newlineremover","off")
    spaceremover=request.POST.get("extraspaceremover","off") 
    lowcaps=request.POST.get("lowcaps","off")
    charactercount=request.POST.get("CharacterCount","off")
    wordcount=request.POST.get("wordcount","off")
    punctuationscount=request.POST.get("punctuationcount","off")
    print(djtext)
    print(removepunc)
    if removepunc == "on":
        punctuations='''.,;:!?'"-–—()\[]{}…/\@#\$%&\*+=<>^\~\`|'''
        analyzed="" 
        for char in djtext:
            if char not in punctuations:
                analyzed= analyzed+char
        params={"purpose":"Remove punctuations","analyzed_text":analyzed}
        return render(request,"analyze.html",params)
    if fullcaps=="on":
        analyzed=""
        for char in djtext:
            analyzed=analyzed+char.upper()
        params = {'purpose': 'Change To Uppercase', 'analyzed_text': analyzed}
        return render(request, 'analyze.html', params)
    if newlineremover=="on":
        analyzed=""
        for char in djtext:
            if char!="/n" and char!="/r ":
                analyzed+=char
        params = {'purpose': ' new line remover   ', 'analyzed_text': analyzed}
        return render(request, 'analyze.html', params)
    if spaceremover=="on":
        analyzed=""
        for char,i in enumerate(djtext):
            if not(djtext[char]==" " and djtext[char+1]==" "):
                analyzed+=i
        params = {'purpose': 'Extra space remover', 'analyzed_text': analyzed}
        return render(request, 'analyze.html', params)
    if lowcaps=="on":
        analyzed=""
        for char in djtext:
            analyzed=analyzed+char.lower()
        params = {'purpose': 'Change To Lowercase', 'analyzed_text': analyzed}
        return render(request, 'analyze.html', params)
    if charactercount=="on":
        count=0
        text=djtext.strip()
        for char in text:
                count+=1
        params = {'purpose': 'charactercount', 'analyzed_text':djtext ,"counted":count}
        return render(request, 'analyze.html', params)
    if wordcount == "on":
        words = djtext.split()
        count = len(words)
        params = {'purpose': 'wordcount', 'analyzed_text':djtext ,"counted":count}
        return render(request, 'analyze.html', params)
    
    if punctuationscount=="on":
        punctuations='''.,;:!?'"-–—()\[]{}…/\@#\$%&\*+=<>^\~\`|'''
        analyzed=""
        count=0
        for char in djtext:
            if char in punctuations:
                count+=1
        params = {'purpose': 'charactercount', 'analyzed_text':djtext ,"counted":count}
        return render(request, 'analyze.html', params)

    if(removepunc!="on" and fullcaps!="on" and newlineremover!="on" and spaceremover!="on" and lowcaps !="on" and charactercount!="on" and wordcount!="on" and punctuationscount!="on"):
        return HttpResponse("error you have to choose atleast one option!!!!")
    